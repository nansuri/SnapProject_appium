package toolsAndDefine;

public class Constant {
	
	// Default Appium Configuration
	public String PACKAGE = "com.snapcart.android";
	public String PACKAGE_ACTIVITY = "com.snapcart.android.ui.login.LoginEmailActivity_";
	public String DEVICE_NAME = "ANDROID";
	
	// Account
	public String EMAIL_VALID = "akundamiggi@gmail.com";
	public String PASS_VALID = "televisi13";
	public String EMAIL_INVALID = "emailsalah@gmail.com";
	public String PASS_INVALID = "12345678";
	
	// UI Test
	public String INVALID_PASS_NOTIF = "Akun yang kamu gunakan belum terdaftar. Silakan cek detil yang kamu masukkan dan coba lagi.";
	public String INVALID_FORGOT_EMAIL_NOTIF = "Email yang kamu masukkan tidak ditemukan";
	public String VALID_FORGOT_EMAIL_NOTIF = "Your password has been reset! Check your e-mail, and re-login";
		
	// Login Page
	public String FORGOT_PASS_BUTTON = "Forgot Password?";
	public String BUTTON_LOGIN_TEXT = "Login";
	
}
